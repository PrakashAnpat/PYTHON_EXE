from django.core.mail import EmailMultiAlternatives
from django.conf import settings
import socket

# impoer celery task
from celery import shared_task

from datetime import datetime
now = datetime.now()

# Asynchronous task class
class AsynchronousTaskNotifications:

    # send email when use login
    @shared_task
    def send_email_token(user_email, current_browser, current_os):
        
        if user_email:
        
            # send email using celery and send system details.    
            hostname = socket.gethostname()
            ip_address = socket.gethostbyname(hostname)
        
            subject = 'welcome to Giftgp store'
            
            html_content = "<b>Hostname : " + str(hostname) + "</b> <br>"
            html_content = html_content + " <b>IP Address : "+ str(ip_address) + "</b><br>"
            html_content = html_content + " <b>Login Browser : " + str(current_browser) + "</b><br>"
            html_content = html_content + "<b>Operating System : " + str(current_os) +"</b><br>"
            html_content = html_content + "<b>Date & Time : " + now.strftime("%d/%m/%Y %H:%M:%S") +"</b><br>"
            
            text_content = 'Login Details.'
            msg = EmailMultiAlternatives(subject, text_content, settings.EMAIL_HOST_USER, [user_email])
            msg.attach_alternative(html_content, "text/html")
            msg.send()
        else:
            print("email is empty.")        
    
    
    # send email as otp and uuid        
    @shared_task
    def send_otp_uuid(user_otp, user_uu_id, to_email):

        if to_email:
            # send otp and uuid using celery.    
            subject = 'Welcome giftgp.'
            text_content = 'Bulk Order OTP and UUID.'
            html_content = '<strong>OTP</strong> : ' + str(user_otp) + '&nbsp;&nbsp;<strong>UUID</strong> : ' + str(user_uu_id)
            
            msg = EmailMultiAlternatives(subject, text_content, settings.EMAIL_HOST_USER, [to_email])
            msg.attach_alternative(html_content, "text/html")
            msg.send()
        else:
            print("email is empty.")  
    
    
    # change password successfully send email
    @shared_task
    def chnage_password_send_email(user_email):
        if user_email:
            # send otp and uuid using celery.    
            subject = 'Welcome giftgp.'
            text_content = 'password detauls'
            html_content = 'Bulk order system succefully update password.'
            
            msg = EmailMultiAlternatives(subject, text_content, settings.EMAIL_HOST_USER, [user_email])
            msg.attach_alternative(html_content, "text/html")
            msg.send()
        else:
            print("email is not found")
    
    
    