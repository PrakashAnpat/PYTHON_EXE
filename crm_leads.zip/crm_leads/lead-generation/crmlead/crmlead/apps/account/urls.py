from django.urls import path,include    
from . import views 
from rest_framework_simplejwt import views as jwt_views
from rest_framework_simplejwt.views import TokenBlacklistView
from .views import MyTokenObtainPairView

from crmlead.apps.account.views import UserRegistration, Profile, AccountRoot,MyTokenObtainPairView, ResetPasswordView, ChangePasswordView
from rest_framework_simplejwt.views import TokenBlacklistView
from rest_framework_simplejwt.views import  TokenRefreshView, TokenVerifyView

urlpatterns = [
    
    path('', AccountRoot.as_view(),name=AccountRoot.name), 
    
    path('api/registration/', UserRegistration.as_view(), name='registration'),
    path('api/profile/', Profile.as_view(), name='profile'),
    path('api/token/', MyTokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('api/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    path('api/reset-password/', ResetPasswordView.as_view(), name='reset-password'),
    path('api/change-password/', ChangePasswordView.as_view(), name='change-password'),
    path('api/verify/', TokenVerifyView().as_view(), name='token_verify'),
    path('api/blacklist/', TokenBlacklistView.as_view(), name='token_blacklist'),
]