from django.shortcuts import render
from .models import User
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework import generics

from rest_framework.generics import CreateAPIView
from rest_framework import status
from .serializers import RegisterSerializer, ResetPasswordSerializer, ChangePasswordSerializer
from rest_framework.reverse import reverse
from .utils import ok_response, error_response
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer
from rest_framework_simplejwt.views import TokenObtainPairView
from .models import ChnagePasswordDetails

from django.contrib.auth import authenticate
from .tasks import AsynchronousTaskNotifications
from rest_framework import serializers
from  django_user_agents .utils import get_user_agent
from .managers import GenerateUUIDOTP

''' server root api view '''
class AccountRoot(generics.GenericAPIView):
    name = 'account-api-root'
    def get(self, request, *args, **kwargs):
        return Response(
            {
                'registration': reverse(UserRegistration.name, request=request), 
                'profile': reverse(Profile.name, request=request), 
                'api-token': reverse('token_obtain_pair', request=request), 
                'refresh-token': reverse('token_refresh', request=request), 
                'verify-token': reverse('token_verify', request=request),  
                'reset-password': reverse(ResetPasswordView.name, request=request), 
                'change-password': reverse(ChangePasswordView.name, request=request), 
                'token-blacklist': reverse('token_blacklist', request=request), 
            })

# Create your views here.
class UserRegistration(generics.CreateAPIView):
    serializer_class = RegisterSerializer

    name = "registration"

    def post(self, request, *args, **kwargs):
        serializer = RegisterSerializer(data=request.data)

        if serializer.is_valid():
            username = request.data.get('username')
            email = request.data.get('email')
            first_name = request.data.get('first_name')
            last_name = request.data.get('last_name')
            phone = request.data.get('phone')
            password = request.data.get('password')

            if not User.objects.filter(username=username).exists():
                if len(password) in range(4, 8):
                    total = len(password) - len(password[-2:])
                    hint_password = ("*"*total+password[-2:])
                else:
                    total = len(password) - len(password[-4:])
                    hint_password = ("*"*total+password[-4:])

                user = User.objects.create(username=username, email=email, first_name=first_name, last_name=last_name, password_hint=hint_password, phone=phone)
                user.set_password(request.data.get('password'))
                user.save()
                
                if user:
                    data = {
                        'username': user.username,
                        'email': user.email,
                        'first_name': user.first_name,
                        'last_name': user.last_name,
                        'phone': user.phone,
                        'password_hint': user.password_hint,
                    }
                    return Response(ok_response(data=data, message='user added successfully.'))
                return Response(error_response(status_code= status.HTTP_400_BAD_REQUEST, message='user not added.', error_details=username))
            else:
                return Response(error_response(status_code=status.HTTP_409_CONFICT, message='username already exit chose diferent username.', error_details=username))
        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class Profile(generics.RetrieveAPIView):
    permission_classes = [IsAuthenticated]
    
    name="profile"
    
    def get(self,request,format=None):
        user= User.objects.get(id=request.user.id)
        content = {
            'username': user.username,  
            'first name': user.first_name,  
            'last name': user.last_name, 
            'email': user.email,    
            'phone': user.phone          
        }
        return Response(content)
        


class MyTokenObtainPairSerializer(TokenObtainPairSerializer):
    
    def validate(self, attrs):
        user = authenticate(username=attrs['username'], password=attrs['password'])
        
        if user is not None:
            if user.is_active:
                token = super().validate(attrs)
                refresh = self.get_token(self.user)
                refresh['username'] = self.user.username
                request = self.context.get('request')
                
                try:
                    
                    # generate token
                    token["refresh"] = str(refresh)
                    token["access"] = str(refresh.access_token)
                    
                    # send email uisng celery tasks.
                    AsynchronousTaskNotifications.send_email_token.delay(user.email, request.user_agent.browser, request.user_agent.os.family) 
                   
                    return token
                
                except Exception as e:
                    raise serializers.ValidationError('Something Wrong.',e)
            else:
                raise serializers.ValidationError('Account is Blocked.')
        else:
            raise serializers.ValidationError('Incorrect username or password.')
    
    
class MyTokenObtainPairView(TokenObtainPairView):
   serializer_class = MyTokenObtainPairSerializer  

    
# reset password view
class ResetPasswordView(generics.CreateAPIView):    
    serializer_class = ResetPasswordSerializer
   
    name="reset-password"
   
    def post(self, request):
        serializer = ResetPasswordSerializer(data=request.data)
        if serializer.is_valid():
            # check email exist
            email = serializer.data.get('email')
            if User.objects.filter(email=email).exists(): 
                user_obj = User.objects.filter(email=email).first()
                
                
                # create unique otp and uuid
                user_otp = GenerateUUIDOTP.generate_otp(self)
                user_uu_id = GenerateUUIDOTP.generate_uuid(self)
            
                check_cred_active = ChnagePasswordDetails.objects.filter(created_for=user_obj, is_active=True).first()
                if check_cred_active:
                    check_cred_active.is_active=False
                    check_cred_active.save()
                else:
                    pass    
                               
                cred = ChnagePasswordDetails.objects.create(otp=user_otp, uu_id=user_uu_id, created_for=user_obj, created_by=user_obj, updated_by=user_obj)
                if cred:
                    cred.save()
                    cred_data = AsynchronousTaskNotifications.send_otp_uuid.delay(user_otp, user_uu_id, email)
                    if cred_data:      
                        data = {'opt':user_otp, 'uuid':user_uu_id, 'email':email}   
                        return Response(ok_response(data=data, message='successfully send OTP and UUID your email account.'))
                    else:
                        return Response(error_response(status_code= status.HTTP_400_BAD_REQUEST, message="OTP and UUID not send", error_details=cred_data))         
                else:
                    return Response(error_response(status_code= status.HTTP_400_BAD_REQUEST, message="credential details not added", error_details=email))           
            else:
                return Response(error_response(status_code= status.HTTP_404_NOT_FOUND, message="email does not exist", error_details=email))
        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
   
    
# chnage password view

class ChangePasswordView(generics.UpdateAPIView):
    """
    An endpoint for changing password.
    """
    serializer_class = ChangePasswordSerializer
    
    name="change-password"
    
    def update(self, request, *args, **kwargs):
        serializer = ChangePasswordSerializer(data=request.data)
        
        if serializer.is_valid():
            new_password = serializer.data.get('new_password')
            otp = serializer.data.get('otp')
            uuid = serializer.data.get('uuid')
            
            cred_obj=ChnagePasswordDetails.objects.filter(uu_id=uuid, is_active=True).first()
            if cred_obj:
                if cred_obj.otp == otp:
                    user=User.objects.get(id=cred_obj.created_for.id, is_active=True)
                    if user:
                        if not user.check_password(new_password):
                            if len(new_password) in range(4, 8):
                                total = len(new_password) -  len(new_password[-2:])
                                hint_password = ("*"*total+new_password[-2:])
                            else:
                                total = len(new_password) -  len(new_password[-4:])
                                hint_password = ("*"*total+new_password[-4:])
                            
                            user.password_hint = hint_password
                            user.set_password(serializer.data.get('new_password'))
                            user.save()      
                            
                            ch_pass_data = ChnagePasswordDetails.objects.filter(id=cred_obj.id).first()
                            ch_pass_data.is_active=False
                            ch_pass_data.save()  
                            AsynchronousTaskNotifications.chnage_password_send_email.delay(user.email)                          
                            return Response(ok_response(data=new_password, message='Password updated successfully.'))    
                        else:
                            return Response(error_response(status_code= status.HTTP_400_BAD_REQUEST, message="New password same as old password choose diffrent password.", error_details=otp)) 
                    else:
                        return Response(error_response(status_code= status.HTTP_404_NOT_FOUND, message="Expire OTP and UUID.", error_details=otp+' '+uuid))
                else:          
                    return Response(error_response(status_code= status.HTTP_400_BAD_REQUEST, message="Invalid OTP", error_details=otp))        
            else:
                return Response(error_response(status_code= status.HTTP_400_BAD_REQUEST, message="Invalid UUID", error_details=uuid))
        else:    
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)      
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    