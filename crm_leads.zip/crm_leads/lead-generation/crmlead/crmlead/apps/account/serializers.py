from .models import User
from rest_framework import serializers
from rest_framework.serializers import ModelSerializer
from  django.contrib.auth import get_user_model
User = get_user_model()

#create and update cloud provider login serializer

class RegisterSerializer(serializers.ModelSerializer):

    class Meta:
        fields = ('id', 'username', 'email', 'first_name', 'last_name', 'phone', 'password')
        model = User

class UserLoginSerializer(ModelSerializer):

    class Meta:
        model = User
        fields = '__all__'

class UserProfileSerailizer(serializers.ModelSerializer):
    class Meta:
        model= User
        fields= '__all__'
        
 
 # token base login        
        
class UserLoginSerializer(serializers.ModelSerializer):
     class Meta:
        model = User
        fields = ('username',  'password')        
        
        
# reset password serializers  
class ResetPasswordSerializer(serializers.Serializer):
    
    """
    Serializer for reset password endpoint.
    """
    email = serializers.EmailField(required=True)


# chnage password serializers
class ChangePasswordSerializer(serializers.Serializer):
    """
    Serializer for password change endpoint.
    """
    new_password = serializers.CharField(required=True)    
    otp = serializers.CharField(required=True)    
    uuid = serializers.CharField(required=True)    

    def validate(self, attrs):    
        
        # special character for password.
        special_char =['$', '@', '#', '%']
        
        if len(attrs['new_password']) < 6:
            raise serializers.ValidationError("password must be at least 6 characters long.")
    
        if len(attrs['new_password']) > 20:
            raise serializers.ValidationError("password length should be not be greater than 20.")  
        
        if not any(char.isdigit() for char in attrs['new_password']):
            raise serializers.ValidationError("password should have at least one numerical digit.")
        
        if not any(char.isupper() for char in attrs['new_password']):
            raise serializers.ValidationError("password should have at least one uppercase letter.")
       
        if not any(char.islower() for char in attrs['new_password']):
            raise serializers.ValidationError("password should have at least one lowercase letter.")
            
        if not any(char in special_char for char in attrs['new_password']):
            raise serializers.ValidationError("password should have at least one special character $, @, #, %.")
        
        return attrs        