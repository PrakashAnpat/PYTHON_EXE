
import random
import uuid
from .models import ChnagePasswordDetails
from django.conf import settings
User = settings.AUTH_USER_MODEL


# generate uuid and otp class
class GenerateUUIDOTP:
    
    # generate otp
    def generate_otp(self):
        # generate random otp
        otp = random.randint(100000, 999999)
        
        if ChnagePasswordDetails.objects.filter(otp=otp).exists():
            return self.generate_otp()
        else:        
            return otp
    
    # generate uuid
    def generate_uuid(self):
        # generate random uuid
        uu_id = uuid.uuid4()
        if ChnagePasswordDetails.objects.filter(uu_id=uu_id).exists():
            return self.generate_uuid()
        else:
            return uu_id




       