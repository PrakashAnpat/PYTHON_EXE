
import json
from django.urls import reverse, resolve
from rest_framework import status
from rest_framework.test import APITestCase
from rest_framework.test import APIClient
from django.test import TestCase
from django.contrib import auth
from django.test import SimpleTestCase 

from rest_framework.authtoken.models import Token

from django.contrib.auth import get_user_model
User = get_user_model()

from crmlead.apps.account.views import UserRegistration, Profile, MyTokenObtainPairView
from crmlead.apps.account.urls import TokenRefreshView, TokenVerifyView, TokenBlacklistView

class TestAcoountTestCases(TestCase):
    def test_account(self):
        self.assertEqual("account", "account")
        
""" Start acccount url resolved """
# Account url resolved
class AccountApiUrlsTests(SimpleTestCase):

    # Registration resolved url
    def test_registration_is_resolved(self):
        url = reverse('registration')
        self.assertEqual(resolve(url).func.view_class, UserRegistration) 
        
    # Profile resolved url
    def test_profile_is_resolved(self):
        url = reverse('profile')
        self.assertEqual(resolve(url).func.view_class, Profile)   
        
    # MyTokenObtainPairView resolved url
    def test_mytokenobtainpairview_is_resolved(self):
        url = reverse('token_obtain_pair')
        self.assertEqual(resolve(url).func.view_class, MyTokenObtainPairView)   
        
  
    # TokenRefreshView resolved url
    def test_tokenrefreshview_is_resolved(self):
        url = reverse('token_refresh')
        self.assertEqual(resolve(url).func.view_class, TokenRefreshView)     
        
    # TokenBlacklistView resolved url
    def test_tokenblacklistview_is_resolved(self):
        url = reverse('token_blacklist')
        self.assertEqual(resolve(url).func.view_class, TokenBlacklistView)      
        
    # TokenVerifyView resolved url
    def test_tokenverifytview_is_resolved(self):
        url = reverse('token_verify')
        self.assertEqual(resolve(url).func.view_class, TokenVerifyView)    
                
""" End acccount url resolved """        
 
 
""" Registration test cases start here """
class ResgistrationTestCases(TestCase):
    
    # db setup
    def setUp(self):
        self.client = APIClient()
        
        # valid payload
        self.valid_payload = {
            'username': 'admin',
            'email':'admin@gmail.com',
            'first_name':'admin',
            'last_name':'admin',
            'phone':'123456789',
            'password':'Admin@gmail.com',
            'confirm_password':'Admin@gmail.com'
        }
        
        # invalid payload
        self.invalid_payload = {
            'username': 1,
            'email':123345,
            'first_name':1,
            'last_name':'admin',
            'phone':'123456789',
            'password':'===+++----',
            'confirm_password':'========'
        }
    # test registtion valid test case  
    def test_create_valid_registration(self):
        response = self.client.post(reverse('registration'),
            data=json.dumps(self.valid_payload),
            content_type='application/json'                            
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        
    # test invalid test case    
    def test_create_invalid_registration(self):
        response = self.client.post(reverse('registration'),
            data=json.dumps(self.invalid_payload),
            content_type='application/json'
        )    
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        
""" Registration test cases end here """
        
        
        
""" Login test cases start here """   
class LoginTestCase(APITestCase):
    
    # db setup
    def setUp(self):
        
        # craete APIClient class object
        self.client = APIClient()
        
        # valid login payload
        self.valid_payload = {
            'username':'admin',
            'password':'Admin@12345'
        }
        
        # invalid payload
        self.invalid_payload = {
            'username':12345,
            'password':'+++===='
        }
        
    # check valid login test case    
    def test_valid_login_test_case(self):
        # valid login credintials
        login_response = self.client.login(username=self.valid_payload['username'], password=self.valid_payload['password'])
        
        if login_response is True:
            response = self.client.post(reverse('token_obtain_pair'),
                data=json.dumps(self.valid_payload),
                content_type='application/json'                          
            )
            self.assertEqual(response.status_code, status.HTTP_200_OK)
        else:
            print("Bad payload")
            
    # check invalid login test case 
    def test_invalid_login_test_case(self):
        # invalid login credntial
        login_response = self.client.login(username=self.invalid_payload['username'], password=self.invalid_payload['password'])
        if login_response is False:
            response = self.client.post(reverse('token_obtain_pair'),
                data=json.dumps(self.invalid_payload),
                content_type='application/json'                       
            )   
            self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        else:
            print("Bad request")
            
""" Login test cases end here """        
        
        
""" profile test case start here """   
class ProfileTestCase(APITestCase):
    
    # db setup
    def setUp(self):
        
        # create user
        self.user = User.objects.create(username='admin', email='admin@gmail.com', first_name="admin", last_name="admin", phone="123456789")
        
        # check token authintications
        self.token = Token.objects.create(user=self.user)
        self.client.credentials(HTTP_AUTHORIZATION='Token ' + self.token.key)
        
    # test user profile test cases 
    def test_user_profile(self):
        response = self.client.get(reverse('profile'))    
        self.assertEqual(response.status_code, status.HTTP_200_OK)  
        
    # test un-autheticated user profile
    def test_un_autheticated_user_profile(self):
        self.client.force_authenticate(user=None, token=None)
        response = self.client.get(reverse('profile'))  
        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)              
          
""" profile test case end here """      


""" reset password start test cases """

class ResetPasswordTestCase(TestCase):
    
    # db setup
    
    def setUp(self):
        self.client = APIClient()
        
        # valid payload
        self.valid_payload = {
            "email":"admin@gmail.com"
        }
        
        # invalid paylaod
        self.invalid_payload = {
            "email":12345
        }

    # test create valid password reset
    def test_create_valid_reset_password(self):
        response = self.client.post(reverse('reset-password'),
            data=json.dumps(self.valid_payload),
            content_type='application/json'
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
    
    # invalid password reset test case
    def test_invalid_reset_password(self):
        response = self.client.post(reverse('reset-password'),
            data=json.dumps(self.invalid_payload),
            content_type='application/json'                            
        )
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        
""" reset password end test cases """


""" password change start test cases here """

class ChangePasswordTestcase(APITestCase):

    # db setup
    def setUp(self):
        self.client = APIClient()
        
        # valid payload
        self.valid_payload = {
            "new_password":"Admin@123456789",
            "otp":"652389",
            "uuid":"58ced02b-e1c5-41ad-93cb-7010d8ff7447"
        }
        
        # invalid payload
        self.invalid_payload = {
            "new_password":"",
            "otp":'-+#@%^&',
            "uuid":123454
        }
        
    # test valid change password test case    
    def test_create_valid_chanage_password_test_case(self):
        response = self.client.put(reverse('change-password'),
            data=json.dumps(self.valid_payload),
            content_type='application/json'
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)  
        
    
    # test invalid change password test case
    def test_invalid_change_password_test_case(self):
        response = self.client.put(reverse('change-password'),
            data=json.dumps(self.invalid_payload),
            content_type='application/json'                           
        )
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
            
""" password change end test cases here """