
from rest_framework.response import Response
from rest_framework import generics
from .models import Campaign
from .serializers import (
    CampaignSerializer,
    CreateAndUpdateCampaignSerializer,
)
from django.contrib.auth.models import User
from rest_framework import status
from rest_framework import filters
from  django_user_agents.utils import get_user_agent
from rest_framework.reverse import reverse
from rest_framework.reverse import reverse


class ApiRoot(generics.GenericAPIView):
    name = 'api-root'
    def get(self, request, *args, **kwargs):
        return Response({
            'view-campaign': reverse(CampaignList.name, request=request),
            'create-campaign': reverse(CreateCampaign.name, request=request),
            })




class CampaignList(generics.ListAPIView):
    queryset = Campaign.objects.filter(is_active=True)
    serializer_class = CampaignSerializer
    filter_backends = [filters.SearchFilter]
    search_fields = ['^name']
    name="view-campaign"  



# Creating compaigns

class CreateCampaign(generics.CreateAPIView):
    queryset = Campaign.objects.all()
    serializer_class = CreateAndUpdateCampaignSerializer
    name="create-campaign"
    def create(self, request, *args, **kwargs):
        response = super().create(request, *args, **kwargs)
        return Response(
            {
            'data': response.data,
            'status': status.HTTP_201_CREATED,
            'message': 'Successfully Create Campaign.',
            'error':{}
            }
        )
    def perform_create(self, serializer):
        serializer.save(created_by_id=self.request.user.id, updated_by_id=self.request.user.id)
        
        
class UpdateCampaign(generics.RetrieveUpdateAPIView):
    queryset = Campaign.objects.all()
    serializer_class = CreateAndUpdateCampaignSerializer
    def put(self, request, *args, **kwargs):
        response = super().update(request, *args, **kwargs)
        
        return Response({
            'data': response.data,
            'status': status.HTTP_201_CREATED,
            'message': 'Successfully update Campaign .',
            'error':{}
        })
        
    # # save current login user id 
    def perform_update(self, serializer):
        serializer.save(updated_by_id=self.request.user.id)        
        
        
class DeleteCampaign(generics.RetrieveDestroyAPIView):
    queryset = Campaign.objects.filter(is_active=True)
    serializer_class = CreateAndUpdateCampaignSerializer
   
    
    def delete(self, request, *args, **kwargs):
        instance = self.get_object()
        instance.is_active=False
        instance.save()
        serializer = self.get_serializer(instance)
        return Response({
            'data': serializer.data,
            'status': status.HTTP_204_NO_CONTENT,
            'message': 'Successfully delete Campaign.',
            'error':{}
        })        