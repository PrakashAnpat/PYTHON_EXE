from django.contrib import admin
from django.urls import path
from .views import  ApiRoot,CampaignList,CreateCampaign,UpdateCampaign,DeleteCampaign
# from take import views

urlpatterns = [
    path('',ApiRoot.as_view(),name=ApiRoot.name),
    
    # compaings urls
    path('view-campaign/', CampaignList.as_view(),name='view-campaign'),
    path('create-campaign/', CreateCampaign.as_view(),name='create-campaign'),
    path('update-campaign/<int:pk>/', UpdateCampaign.as_view(),name='update-campaign'),
    path('Delete-campaign/<int:pk>/', DeleteCampaign.as_view(),name='delete-campaign'),

]