from django.db import models
from django.conf import settings
User = settings.AUTH_USER_MODEL
# Create your models here.
    
class Campaign(models.Model):
    code = models.CharField(max_length=10, db_index=True, unique=True)
    name = models.CharField(max_length=32, blank=False, null=False,)
    purpose= models.CharField(max_length=50, blank=False, null=False,)
    description = models.TextField(null=True, blank=True)
    status = models.BooleanField(default=False)
    created_by = models.ForeignKey(User,related_name="campaign_cretated_by",on_delete=models.PROTECT)
    updated_by = models.ForeignKey(User,related_name="campaign_updated_by",on_delete=models.PROTECT)
    created_on = models.DateTimeField(auto_now_add=True, null=True)
    updated_on = models.DateTimeField(auto_now=True, null=True)
    is_active = models.BooleanField(default=True)
    
    
    def __str__(self):
        return self.code