from django.contrib import admin
from .models import Campaign
# Register your models here.



# admin.site.register(Campaign)  
class CampaignAdmin(admin.ModelAdmin):
    list_display = ('code','name','status','created_by',) 
admin.site.register(Campaign, CampaignAdmin)    
  