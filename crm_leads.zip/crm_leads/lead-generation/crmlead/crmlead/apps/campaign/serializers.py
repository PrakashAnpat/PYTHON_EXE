from django.contrib.auth.models import User, Group
from rest_framework import serializers
from .models import Campaign


      
class CampaignSerializer(serializers.ModelSerializer):
    update_campaign = serializers.HyperlinkedIdentityField(view_name='update-campaign')
    delete_campaign = serializers.HyperlinkedIdentityField(view_name='delete-campaign')  
    
    class Meta:
        model = Campaign
        fields = ('id','code','name','purpose','description','status','updated_by','update_campaign','delete_campaign')
       
    def to_representation(self, instance):
        ret = super().to_representation(instance)
        ret['created_by'] =  instance.created_by.username
        ret['updated_by'] =  instance.updated_by.username
        return ret     


class CreateAndUpdateCampaignSerializer(serializers.ModelSerializer):
    update_campaign = serializers.HyperlinkedIdentityField(view_name='update-campaign')
    delete_campaign = serializers.HyperlinkedIdentityField(view_name='delete-campaign')      
    
    class Meta:
        model = Campaign
        fields = ('code','name','purpose','description','status','created_by','updated_by','update_campaign','delete_campaign')
        
        
    def to_representation(self, instance):
        ret = super().to_representation(instance)
        ret['created_by'] =  instance.created_by.username
        ret['updated_by'] =  instance.updated_by.username
        return ret  