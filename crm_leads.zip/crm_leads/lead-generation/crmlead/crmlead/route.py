
from rest_framework.response import Response
from rest_framework.decorators import api_view

@api_view(['GET'])
def getRoutes(request):
    domain = request.META['HTTP_HOST']
    if request.scheme == 'https':
       security_protocol = 'https'
    else:
        security_protocol = 'http' 

    return Response(
        {
            'admin': security_protocol+'://'+ domain +'/admin/',
            'accounts': security_protocol+'://'+ domain +'/accounts/',
            'campaign': security_protocol+'://'+ domain +'/campaign/',
        })