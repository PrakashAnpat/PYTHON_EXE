# Development ENV
from crmlead.settings import *

# Development env set DEBUG=TRUE
DEBUG=True

# Development allowed host
ALLOWED_HOSTS = ['*']

# Development Database
DATABASES = {
    'default': {
        'ENGINE': os.environ.get('ENGINE'),
        'NAME': os.environ.get('NAME'),
        'USER': os.environ.get('USER'),
        'PASSWORD': os.environ.get('PASSWORD'),
        'HOST': os.environ.get('HOST'),
        'PORT': os.environ.get('PORT'),
    }
}
