from django.contrib import admin
from django.urls import path,include
from . import route

from django.contrib import admin
admin.site.site_header = 'Bulk Order'                    # default: "Django Administration"
admin.site.index_title = 'Bulk Order'                 # default: "Site administration"
admin.site.site_title = 'Bulk Order' # default: "Django site admin"


urlpatterns = [
    
    path('api-auth/', include('rest_framework.urls', namespace='rest_framework')), # remove this url can't show login button in django rest framework UI.
    
    path('', route.getRoutes),    
    path('admin/', admin.site.urls),
    path('accounts/', include('crmlead.apps.account.urls')),
    path('campaign/', include('crmlead.apps.campaign.urls')),
]
