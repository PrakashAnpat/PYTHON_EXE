  
# 1] How to run celery in Django rest framework

```
celery -A crmlead worker --loglevel=info


```
# 2] Run flower

 celery -A crmlead flower 

```

# Development environment 

export DJANGO_ENV=development
export APP_SETTINGS=crmlead.development
export ENGINE=django.db.backends.postgresql
export NAME=api_bulk_order
export USER=postgres
export PASSWORD=giridhar
export HOST=127.0.0.1
export PORT=5432